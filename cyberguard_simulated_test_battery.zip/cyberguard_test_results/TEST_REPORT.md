# CyberGuard XDR Beta 1.0 — Simulated Test Report

Date: 2026-11-10. Target: original, unmodified application in `/mnt/data/cyberguard_xdr`.

## Results

- Original regression suite: **4 passed / 4**.
- Extended simulation suite: **26 passed / 30**, **3 failed**, **1 error**.
- Total automated checks: **30 passed / 34**, **3 failed**, **1 error**.
- CLI demo run: **successful**, generating 5 assets, 4 alerts, 1 incident and 2 exposures from synthetic fixtures.
- No production hosts, live Wazuh, live Ansible hosts, NVD/KEV/EPSS APIs, or real network attacks were tested.

## Findings

| ID | Priority | Test | Observed behavior | Remediation |
|---|---|---|---|---|
| CG-01 | High | Duplicate alert IDs | Replaying the same alert 3 times creates a false brute-force incident | Deduplicate by stable event ID + agent/source and track ingestion provenance |
| CG-02 | Medium | Duplicate asset hostnames | Silent overwrite in asset dictionary | Reject duplicates or explicitly merge with conflict evidence |
| CG-03 | Medium | NaN EPSS input | Invalid non-finite score accepted without error | Reject non-finite numbers and validate EPSS range 0..1 |
| CG-04 | Medium | Negative correlation window | IndexError rather than a controlled validation error | Validate window_minutes >= 0 and threshold >= 1 before processing |

## Limitations

Passing tests validate only the listed synthetic scenarios; they do not establish production readiness, complete XDR functionality, NIST compliance, or MITRE detection coverage. The 30 extended tests are scenario-specific and include expected failures that expose implementation defects.

## Reproduce

```bash
cd /mnt/data/cyberguard_xdr
python3 -m unittest discover -s tests -v
python3 /mnt/data/cyberguard_test_results/test_extended.py
python3 -m cyberguard --alerts samples/alerts.jsonl --assets samples/assets.json --exposures samples/exposures.json --output /tmp/cyberguard-demo
```
