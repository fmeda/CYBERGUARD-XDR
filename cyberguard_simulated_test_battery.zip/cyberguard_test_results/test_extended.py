import unittest, tempfile, json, sys
from pathlib import Path
sys.path.insert(0,'/mnt/data/cyberguard_xdr')
from cyberguard.core import *
from cyberguard.report import render
ROOT=Path('/mnt/data/cyberguard_xdr')
def ev(i, minute, host='srv', ip='192.0.2.1', rule='5710', level=8):
 return normalize_alert({'id':str(i),'timestamp':f'2026-11-10T10:{minute:02d}:00Z','agent':{'name':host},'rule':{'id':rule,'level':level},'data':{'srcip':ip}})
class Extended(unittest.TestCase):
 def test_threshold_below(self): self.assertEqual(len(correlate([ev(1,0),ev(2,1)],{})),0)
 def test_threshold_exact(self): self.assertEqual(len(correlate([ev(1,0),ev(2,1),ev(3,2)],{})),1)
 def test_window_outside(self): self.assertEqual(len(correlate([ev(1,0),ev(2,11),ev(3,22)],{})),0)
 def test_window_boundary(self): self.assertEqual(len(correlate([ev(1,0),ev(2,5),ev(3,10)],{})),1)
 def test_separate_hosts(self): self.assertEqual(len(correlate([ev(1,0,'a'),ev(2,1,'a'),ev(3,2,'b')],{})),0)
 def test_separate_ips(self): self.assertEqual(len(correlate([ev(1,0,ip='192.0.2.1'),ev(2,1,ip='192.0.2.2'),ev(3,2,ip='192.0.2.3')],{})),0)
 def test_unsorted(self): self.assertEqual(len(correlate([ev(3,2),ev(1,0),ev(2,1)],{})),1)
 def test_missing_source(self): self.assertEqual(len(correlate([ev(1,0,ip=''),ev(2,1,ip=''),ev(3,2,ip='')],{})),0)
 def test_invalid_timestamp(self):
  a=[ev(1,0),ev(2,1),ev(3,2)];a[0]['timestamp']='invalid';self.assertEqual(len(correlate(a,{})),0)
 def test_no_alerts(self): self.assertEqual(correlate([],{}),[])
 def test_risk_clamped(self): self.assertEqual(risk_score(999,'critical',True,1),100)
 def test_risk_negative(self): self.assertEqual(risk_score(-10,'low'),0)
 def test_risk_kev(self): self.assertGreater(risk_score(5,kev=True),risk_score(5))
 def test_risk_epss(self): self.assertGreater(risk_score(5,epss=0.9),risk_score(5,epss=0.1))
 def test_risk_invalid_epss_rejected(self):
  with self.assertRaises(ValueError):risk_score(5,epss='not-a-number')
 def test_assets_invalid_root(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.json';p.write_text('{}');
   with self.assertRaises(ValueError):load_assets(p)
 def test_assets_missing_hostname(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.json';p.write_text('[{"os":"linux"}]');
   with self.assertRaises(ValueError):load_assets(p)
 def test_jsonl_and_array(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.json';p.write_text(json.dumps([{'rule':{'id':'5710'}}]));self.assertEqual(len(parse_alerts(p)),1)
 def test_empty_alerts(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.jsonl';p.write_text('');self.assertEqual(parse_alerts(p),[])
 def test_malformed_json_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.jsonl';p.write_text('{broken');
   with self.assertRaises(json.JSONDecodeError):parse_alerts(p)
 def test_sha256_integrity(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a';p.write_text('A');h=sha256(p);p.write_text('B');self.assertNotEqual(h,sha256(p))
 def test_report_escaping(self):
  r=analyze(ROOT/'samples/alerts.jsonl',ROOT/'samples/assets.json',ROOT/'samples/exposures.json');r['exposures'][0]['package']='<img src=x onerror=alert(1)>'
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'r.html';render(r,p);self.assertNotIn('<img src=x onerror=alert(1)>',p.read_text())
 def test_exposures_sorted(self):
  r=analyze(ROOT/'samples/alerts.jsonl',ROOT/'samples/assets.json',ROOT/'samples/exposures.json');s=[x['risk_score'] for x in r['exposures']];self.assertEqual(s,sorted(s,reverse=True))
 def test_missing_alert_file_handled(self):
  with self.assertRaises(FileNotFoundError):analyze('/missing/cyberguard_alerts.jsonl',ROOT/'samples/assets.json')
 def test_duplicate_alert_deduplication(self):
  a=ev(1,0);self.assertEqual(len(correlate([a,a,a],{})),0,'duplicate event IDs should not count as 3 failures')
 def test_successful_login_not_bruteforce(self):
  a=[ev(i,i) for i in range(3)]
  for x in a:x['rule_id']='5715';x['kind']='incident'
  self.assertEqual(len(correlate(a,{})),0)
 def test_mixed_timezone_sorting(self):
  a=[ev(1,0),ev(2,1),ev(3,2)];a[0]['timestamp']='2026-11-10T10:00:00';self.assertEqual(len(correlate(a,{})),1)
 def test_duplicate_asset_hostname_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.json';p.write_text('[{"hostname":"a"},{"hostname":"a"}]');
   with self.assertRaises(ValueError):load_assets(p)
 def test_nan_epss_rejected(self):
  with self.assertRaises(ValueError):risk_score(5,epss=float('nan'))
 def test_negative_window_rejected(self):
  with self.assertRaises(ValueError):correlate([ev(1,0),ev(2,1),ev(3,2)],{},window_minutes=-1)
if __name__=='__main__':unittest.main(verbosity=2)
