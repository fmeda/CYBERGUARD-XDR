# CyberGuard XDR — Infrastructure Threat & Exposure Analyzer

**Version:** 1.0.0-beta | **License:** MIT | **Python:** 3.10+ | **Mode:** Read-only

A defensive, offline-first proof-of-concept for infrastructure evidence correlation. It accepts Wazuh alert exports, a normalized asset inventory, and an optional *externally curated* vulnerability-enrichment file. It generates JSON findings and a standalone HTML dashboard. The project **does not** provide native live Wazuh API polling, CVE database synchronization, remediation, or a complete XDR platform.

## Quick start (Linux)

```bash
unzip cyberguard_xdr_beta.zip
cd cyberguard_xdr
python3 -m unittest discover -s tests -v
python3 -m cyberguard --alerts samples/alerts.jsonl --assets samples/assets.json --exposures samples/exposures.json --output output
xdg-open output/dashboard.html
```

No third-party Python packages required. The demo uses **synthetic** events and fictional CVE IDs; its scores do not describe real-world exposures.

## Inputs

- `--alerts`: exported Wazuh `alerts.json` newline-delimited JSON or JSON array. Each record should contain `timestamp`, `agent.name`, `rule.id`, `rule.level`; `data.srcip` is needed for authentication correlation.
- `--assets`: JSON list of objects with `hostname`, `criticality` (`low`, `medium`, `high`, `critical`), `os`, `owner`, `environment`.
- `--exposures`: optional JSON list of `hostname`, `cve`, `package`, `installed_version`, `level`, `kev`, `epss`, `evidence_source`. These values are *input claims*, not independently verified.

## Outputs

- `output/report.json`: normalized incidents, exposure triage, source SHA-256 and limitations.
- `output/dashboard.html`: local static dashboard; no network calls or JavaScript dependencies.

## Optional Ansible collection

Requires `ansible-core` on the controller. Edit `ansible/inventory.ini`, then run:

```bash
mkdir -p output
ansible-playbook -i ansible/inventory.ini ansible/collect.yml
```

Collection is read-only on remote Linux hosts, but writes local evidence JSON on the controller. **The collected evidence is not automatically imported into the asset schema or scoring engine in this beta.** Ansible gather_facts may require Python on managed hosts. Protect reports because socket information and host metadata may be sensitive.

## Integration with Wazuh

Export a *copy* of Wazuh manager alert JSONL, typically `/var/ossec/logs/alerts/alerts.json`, into an authorized analysis workspace. Avoid giving the analyzer privileged access to the manager. Use a read-only, least-privilege export workflow and redact sensitive fields as required by policy. This beta reads exported files, not live API streams.

## Correlation and scoring

The authentication rule correlates >=3 SSH authentication alerts from the same source IP to the same host within a 10-minute sliding window. One maximum-sized incident per pair is reported, not multiple independent incident clusters. MITRE ATT&CK `T1110` is a hypothesis; investigate before confirming compromise. NIST CSF 2.0 references are illustrative. Risk score is an explicitly heuristic weighted triage metric, not a CVSS or likelihood measure. No automated blocking.

## Known limitations

No persistent database, RBAC, secrets management, vendor API connector, native Wazuh rule ingestion beyond export, automatic CVE/KEV/EPSS validation, deduplication across files, live dashboard, false-positive feedback loop, SLA engine, alerting integrations, or production hardening. Before enterprise deployment, implement these controls, input-size limits, safe retention, authentication, schema validation, audit logging, observability, and integration tests with real sanitized data.

## Responsible use

Use only with authorized assets and logs. No exploit or attack capabilities are included. Treat reports as confidential. Do not use synthetic demonstration data for operational decisions.
