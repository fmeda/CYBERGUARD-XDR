import argparse
import json
from pathlib import Path
from .core import analyze
from .report import render

def main():
    parser = argparse.ArgumentParser(description='CyberGuard XDR - defensive read-only evidence analyzer')
    parser.add_argument('--alerts', required=True, help='Wazuh alerts JSONL or JSON array')
    parser.add_argument('--assets', required=True, help='Asset inventory JSON array')
    parser.add_argument('--exposures', help='Optional offline CVE enrichment JSON array')
    parser.add_argument('--output', default='output', help='Output directory')
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    result = analyze(args.alerts, args.assets, args.exposures)
    (output / 'report.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    render(result, output / 'dashboard.html')
    print(json.dumps({'status': 'ok', 'summary': result['summary'], 'output': str(output.resolve())}, indent=2))

if __name__ == '__main__':
    main()
