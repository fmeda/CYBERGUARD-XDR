"""CyberGuard XDR: offline, read-only security evidence correlation."""
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ATTACK = {
    '5710': ('T1110', 'Brute Force'),
    '5712': ('T1110', 'Brute Force'),
    '550': ('T1098', 'Account Manipulation'),
    '554': ('T1098', 'Account Manipulation'),
    '100001': ('T1078', 'Valid Accounts'),
}
NIST = {'authentication': 'DE.CM', 'configuration': 'PR.PS', 'vulnerability': 'ID.RA', 'incident': 'RS.AN'}

def load_json(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(65536), b''):
            h.update(block)
    return h.hexdigest()

def normalize_alert(raw):
    rule = raw.get('rule') or {}
    agent = raw.get('agent') or {}
    data = raw.get('data') or {}
    groups = rule.get('groups') or []
    rid = str(rule.get('id', 'unknown'))
    attack = rule.get('mitre') or {}
    technique = (attack.get('id') or [None])[0] if isinstance(attack.get('id'), list) else attack.get('id')
    mapped = ATTACK.get(rid)
    if not technique and mapped:
        technique = mapped[0]
    kind = 'authentication' if ('authentication_failed' in groups or 'sshd' in groups or rid in ('5710', '5712')) else 'incident'
    return {
        'id': str(raw.get('id', 'unknown')),
        'timestamp': str(raw.get('timestamp', '')),
        'agent': str(agent.get('name', 'unknown')),
        'agent_id': str(agent.get('id', 'unknown')),
        'rule_id': rid,
        'level': int(rule.get('level', 0)),
        'description': str(rule.get('description', '')),
        'source_ip': str(data.get('srcip') or raw.get('srcip') or ''),
        'technique': technique,
        'nist': NIST[kind],
        'kind': kind,
    }

def parse_alerts(path):
    p = Path(path)
    if not p.exists():
        return []
    content = p.read_text(encoding='utf-8').strip()
    if not content:
        return []
    if content.startswith('['):
        records = json.loads(content)
    else:
        records = [json.loads(line) for line in content.splitlines() if line.strip()]
    return [normalize_alert(record) for record in records]

def load_assets(path):
    raw = load_json(path)
    if not isinstance(raw, list):
        raise ValueError('assets JSON must be a list')
    assets = {}
    for item in raw:
        if not isinstance(item, dict) or not item.get('hostname'):
            raise ValueError('each asset needs hostname')
        assets[item['hostname']] = {
            'hostname': item['hostname'],
            'criticality': item.get('criticality', 'medium'),
            'os': item.get('os', 'unknown'),
            'owner': item.get('owner', 'unassigned'),
            'environment': item.get('environment', 'unknown'),
        }
    return assets

def risk_score(level, criticality='medium', kev=False, epss=None):
    """Heuristic triage score, not a validated probability of compromise."""
    weights = {'low': 0, 'medium': 10, 'high': 20, 'critical': 30}
    score = max(0, min(15, int(level))) * 3 + weights.get(str(criticality).lower(), 10)
    if kev is True:
        score += 20
    if epss is not None:
        score += round(max(0.0, min(1.0, float(epss))) * 15)
    return min(100, score)

def severity(score):
    if score >= 80: return 'critical'
    if score >= 60: return 'high'
    if score >= 35: return 'medium'
    return 'low'

def correlate(alerts, assets, window_minutes=10, threshold=3):
    """Correlate authentication alerts per source IP and asset within a time window."""
    groups = defaultdict(list)
    for alert in alerts:
        if alert['kind'] != 'authentication' or not alert['source_ip']:
            continue
        try:
            ts = datetime.fromisoformat(alert['timestamp'].replace('Z', '+00:00'))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        groups[(alert['agent'], alert['source_ip'])].append((ts, alert))
    incidents = []
    for (host, ip), events in groups.items():
        events.sort(key=lambda item: item[0])
        left = 0
        best = []
        for right, (ts, _) in enumerate(events):
            while (ts - events[left][0]).total_seconds() > window_minutes * 60:
                left += 1
            current = events[left:right + 1]
            if len(current) >= threshold and len(current) > len(best):
                best = current[:]
        if best:
            criticality = assets.get(host, {}).get('criticality', 'medium')
            score = risk_score(max(event['level'] for _, event in best), criticality)
            incidents.append({
                'type': 'Repeated Authentication Failures',
                'asset': host, 'source_ip': ip,
                'count': len(best), 'start': best[0][0].isoformat(),
                'end': best[-1][0].isoformat(),
                'rule_ids': sorted(set(event['rule_id'] for _, event in best)),
                'alert_ids': [event['id'] for _, event in best],
                'mitre': 'T1110', 'nist': 'DE.CM',
                'risk_score': score, 'severity': severity(score),
                'confidence': 'medium',
                'recommendation': 'Validate account activity and source; review access controls and authentication logs before containment.',
            })
    return sorted(incidents, key=lambda x: x['risk_score'], reverse=True)

def assess_exposures(path, assets):
    if not path or not Path(path).exists():
        return []
    records = load_json(path)
    if not isinstance(records, list):
        raise ValueError('exposures JSON must be a list')
    findings = []
    for item in records:
        host = str(item['hostname'])
        kev = item.get('kev', False)
        epss = item.get('epss')
        score = risk_score(int(item.get('level', 5)), assets.get(host, {}).get('criticality', 'medium'), kev, epss)
        findings.append({
            'hostname': host, 'cve': str(item['cve']), 'package': str(item.get('package', 'unknown')),
            'installed_version': str(item.get('installed_version', 'unknown')),
            'kev': kev, 'epss': epss, 'risk_score': score, 'severity': severity(score),
            'nist': 'ID.RA', 'evidence_source': str(item.get('evidence_source', 'provided inventory')),
            'verification': 'Unverified external enrichment; validate affected versions, vendor advisory, and remediation.',
        })
    return sorted(findings, key=lambda x: x['risk_score'], reverse=True)

def analyze(alert_path, asset_path, exposure_path=None):
    assets = load_assets(asset_path)
    alerts = parse_alerts(alert_path)
    incidents = correlate(alerts, assets)
    exposures = assess_exposures(exposure_path, assets)
    return {
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'mode': 'read-only', 'status': 'beta',
        'sources': {'alerts': {'path': str(alert_path), 'sha256': sha256(alert_path)},
                    'assets': {'path': str(asset_path), 'sha256': sha256(asset_path)},
                    'exposures': {'path': str(exposure_path), 'sha256': sha256(exposure_path)} if exposure_path and Path(exposure_path).exists() else None},
        'summary': {'assets': len(assets), 'alerts': len(alerts), 'incidents': len(incidents),
                    'exposures': len(exposures), 'alert_levels': dict(Counter(str(a['level']) for a in alerts))},
        'incidents': incidents, 'exposures': exposures,
        'frameworks': {'MITRE ATT&CK': 'Technique IDs are mappings, not proof of attacker behavior',
                       'NIST CSF 2.0': 'Outcome references are indicative, not compliance certification'},
        'limitations': ['No live CVE lookup', 'No endpoint response actions', 'No automated exploitation',
                        'No guaranteed threat attribution', 'Not a full XDR replacement'],
    }
