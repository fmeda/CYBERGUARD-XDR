"""Static HTML dashboard with escaped user-supplied values."""
import html
import json
from pathlib import Path

def render(report, output):
    e = lambda value: html.escape(str(value), quote=True)
    summary = report['summary']
    def rows(items, fields):
        return ''.join('<tr>' + ''.join(f'<td>{e(item.get(field, ""))}</td>' for field in fields) + '</tr>' for item in items)
    incident_fields = ['severity', 'asset', 'source_ip', 'count', 'mitre', 'nist', 'recommendation']
    exposure_fields = ['severity', 'hostname', 'cve', 'package', 'kev', 'epss', 'risk_score', 'verification']
    def table(items, fields):
        return '<div class="scroll"><table><thead><tr>' + ''.join(f'<th>{e(f)}</th>' for f in fields) + '</tr></thead><tbody>' + (rows(items, fields) or f'<tr><td colspan="{len(fields)}">No findings</td></tr>') + '</tbody></table></div>'
    doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CyberGuard XDR | Evidence Dashboard</title><style>
    :root{{color-scheme:dark}}body{{background:#0b1220;color:#e5edf8;font:15px system-ui,Arial,sans-serif;margin:0}}header{{background:#111e33;padding:30px 5%;border-bottom:1px solid #293a53}}h1{{margin:0;color:#71d5c5}}h2{{margin-top:35px}}main{{padding:20px 5% 50px}}.metrics{{display:flex;gap:12px;flex-wrap:wrap}}.metric{{background:#15243a;border:1px solid #29435d;border-radius:10px;padding:18px;min-width:130px;flex:1}}.metric b{{font-size:28px;color:#71d5c5;display:block}}table{{border-collapse:collapse;width:100%;min-width:780px}}th,td{{padding:11px;text-align:left;border-bottom:1px solid #29405b;vertical-align:top}}th{{color:#71d5c5;background:#15243a}}.scroll{{overflow-x:auto}}.notice{{padding:15px;background:#182d3c;border-left:4px solid #71d5c5;margin-top:25px}}small{{color:#afc0d7}}
    </style></head><body><header><h1>CYBERGUARD XDR</h1><p>Infrastructure Threat & Exposure Analyzer | Beta | Read-only</p><small>Generated: {e(report['generated_at'])}</small></header><main><section class="metrics">'''
    for label, value in [('Assets',summary['assets']),('Alerts',summary['alerts']),('Incidents',summary['incidents']),('Exposures',summary['exposures'])]:
        doc += f'<div class="metric"><b>{e(value)}</b>{e(label)}</div>'
    doc += '</section><h2>Correlated Incidents</h2>' + table(report['incidents'], incident_fields)
    doc += '<h2>Exposure Findings</h2>' + table(report['exposures'], exposure_fields)
    doc += '<div class="notice"><b>Evidence & limitations</b><p>Risk scores are heuristic. CVE/KEV/EPSS inputs must be independently validated. ATT&CK mapping does not prove compromise. NIST mapping does not establish compliance.</p></div>'
    doc += '<h2>Source Integrity (SHA-256)</h2><pre>' + e(json.dumps(report['sources'], indent=2)) + '</pre></main></body></html>'
    Path(output).write_text(doc, encoding='utf-8')
