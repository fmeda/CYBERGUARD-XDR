import json
import tempfile
import unittest
from pathlib import Path
from cyberguard.core import analyze, correlate, normalize_alert, risk_score
from cyberguard.report import render

ROOT = Path(__file__).resolve().parents[1]
class CyberGuardTests(unittest.TestCase):
    def test_demo(self):
        r = analyze(ROOT/'samples/alerts.jsonl', ROOT/'samples/assets.json', ROOT/'samples/exposures.json')
        self.assertEqual(r['summary']['assets'], 5)
        self.assertEqual(r['summary']['incidents'], 1)
        self.assertEqual(r['summary']['exposures'], 2)
        self.assertEqual(r['incidents'][0]['mitre'], 'T1110')
    def test_risk_bounds(self):
        self.assertEqual(risk_score(99, 'critical', True, 1), 100)
        self.assertGreater(risk_score(8, 'critical'), risk_score(8, 'low'))
    def test_no_false_correlation_across_source(self):
        events = []
        for i in range(3):
            events.append(normalize_alert({'id': str(i), 'timestamp': f'2026-11-10T10:0{i}:00Z', 'agent': {'name': 'a'}, 'rule': {'id': '5710', 'level': 8}, 'data': {'srcip': f'192.0.2.{i}'}}))
        self.assertEqual(correlate(events, {}), [])
    def test_html_escape(self):
        r = analyze(ROOT/'samples/alerts.jsonl', ROOT/'samples/assets.json')
        r['incidents'][0]['asset'] = '<script>alert(1)</script>'
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)/'report.html'
            render(r, dest)
            content = dest.read_text()
            self.assertNotIn('<script>alert(1)</script>', content)
            self.assertIn('&lt;script&gt;', content)
if __name__ == '__main__':
    unittest.main()
